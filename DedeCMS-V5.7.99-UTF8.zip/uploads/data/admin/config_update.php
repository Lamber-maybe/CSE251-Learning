<?php
/**
 * 更新服务器，如果有变动，请到 http://bbs.dedecms.com 查询
 *
 * @version        $Id: config_update.php 1 11:36 2011-2-21 $
 * @package        DedeCMS.Administrator
 * @founder        IT柏拉图, https://weibo.com/itprato
 * @author         DedeCMS团队
 * @copyright      Copyright (c) 2007 - 2021, 上海卓卓网络科技有限公司 (DesDev, Inc.)
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */

//更新服务器，如果有变动，请到 http://bbs.dedecms.com 查询

define('UPDATEHOST', 'https://updatenew.dedecms.com/base-v57/');
define('LINKHOST', 'http://flink.dedecms.com/server_url.php');
