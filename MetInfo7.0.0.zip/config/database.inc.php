<?php

return array(
    'db_type' => 'mysql',
    'db_name' => 'config/metinfo.db',
);
