<?php
# MetInfo Enterprise Content Management System
# Copyright (C) MetInfo Co.,Ltd (http://www.metinfo.cn). All rights reserved.
defined('IN_MET') or exit('No permission');
?>
<div class="met-partner">
	<nav class="nav nav-pills mb-3"></nav>
	<div class="tab-content"></div>
</div>