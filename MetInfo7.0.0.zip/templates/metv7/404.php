<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" />
 <section class="page404">
    <div class="container text-xs-center box404">
        <div class="met-editor">
        	{$c.met_404content}
        </div>
    </div>
  </section>
<include file="foot.php" />