<?php
global $metinfover;
// 模板引擎
$metinfover                  = "v2";
$template_type                  = "tag";
// 栏目可用字段
$metadmin[categorynamemark]  = 1; // 栏目修饰名称
$metadmin[categoryimage]     = 1; // 栏目图片
$metadmin[categorymarkimage] = 0; // 栏目标识图片
// banner描述文字、文字位置、颜色等设置
$metadmin[system_flash_option_ok]=array(
	all=>1,
	img_des=>1,
	img_title_color=>1,
	img_des_color=>1,
	img_text_position=>1
);
?>