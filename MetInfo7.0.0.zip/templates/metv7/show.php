<?php defined('IN_MET') or exit('No permission'); ?>
<include file="head.php" />
<section class="met-show-body" m-id="noset">
    <div class="container">
        <div class="met-editor clearfix">
            {$data.content}
        </div>
    </div>
</section>
<include file="foot.php" />