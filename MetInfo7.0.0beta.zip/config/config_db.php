<?php
                   /*
                   con_db_host = ""
                   con_db_port = ""
                   con_db_id   = ""
                   con_db_pass	= ""
                   con_db_name = ""
                   tablepre    =  ""
                   db_charset  =  "";
                  */
                  ?>